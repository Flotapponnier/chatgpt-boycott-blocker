# ChatGPT Block

Extension qui redirige automatiquement ChatGPT vers Claude.

## Installation

### Chrome/Edge
1. Ouvre `chrome://extensions/`
2. Active le "Mode développeur"
3. Clique "Charger l'extension non empaquetée"
4. Sélectionne le dossier `chatgpt_block`

### Firefox
1. Ouvre `about:debugging#/runtime/this-firefox`
2. Clique "Charger un module temporaire"
3. Sélectionne le fichier `manifest.json`

## Utilisation

Une fois installée, l'extension redirige automatiquement toute visite sur chatgpt.com vers claude.ai.
